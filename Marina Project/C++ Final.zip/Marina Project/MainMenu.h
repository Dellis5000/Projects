#pragma once
class Menu {
public:
	//Menu Method definition
	void DisplayMenu();
	void NewBooking();
	void DisplayBooking();
	void DeleteBooking();
	
};
